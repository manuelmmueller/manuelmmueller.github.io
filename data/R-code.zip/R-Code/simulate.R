# Author: Manuel Mueller, mm2559@cam.ac.uk
# Description: Reproduce the simulation results in https://arxiv.org/abs/2305.04852v2

#rm(list = ls())

# ============= 0. Setup =======================================================

library(ISS)  # requires version 1.0.0 or higher

# load file with seeds and setting information
sim_settings <- get(load("sim_settings_revision.RData"))


# ============= 1. Choose experiment indices to reproduce ======================
# next line: CHOOSE E.g. 1 for first experiment, 1:5 for first five, 1:nrow(sim_settings) for all
ind <- 1:nrow(sim_settings)


# ==============================================================================
# ================ FROM HERE ONWARDS: AVOID MAKING CHANGES =====================
# ============= 2. Prepare simulations  ========================================
# fixed parameters
p_value_method <- "sub-Gaussian-normalmixture"
rho <- 1/2
alpha <- 0.05
split_proportion <- 1/2

# utility function for evaluating simulation runs
superlevelset_evaluation <- function(X, X_rej, t, f) {
  # X...points of interest
  # X_rej...points whose upper hull is the selected set
  # t...superlevelset threshold
  # f...regression function
  n <- nrow(X)
  d <- ncol(X)
  
  # get the corresponding values of the regression function
  f_X <- apply(X, MARGIN = 1, FUN = f)
  
  # get the points in the superlevelset
  X_in_superlevelset <- X[f_X >= t,,drop = F]
  number_of_points_in_superlevelset <- nrow(X_in_superlevelset)
  
  # get the selected set in minimal form
  X_rej_boundary <- get_boundary_points(X_rej)
  
  # evaluate for each point in X the superlevelset whether it is in the selected set
  X_in_superlevelset_rej_bool <- rep(NA, number_of_points_in_superlevelset)
  if (number_of_points_in_superlevelset == 0) {
    number_of_selected_points_in_superlevelset <- 0
  } else {
    for (l in 1:number_of_points_in_superlevelset) {
      x0 <- X_in_superlevelset[l,]
      X_in_superlevelset_rej_bool[l] <- any(apply(X_rej_boundary, MARGIN = 1, FUN = function(x) all(x <= x0)))
    }
    number_of_selected_points_in_superlevelset <- sum(X_in_superlevelset_rej_bool)
  }
  
  return(list(number_of_points_in_superlevelset = number_of_points_in_superlevelset,
              number_of_selected_points_in_superlevelset = number_of_selected_points_in_superlevelset))
  
}


# ============= 3. Run simulations  ============================================
# progress bar might be misleading since computation times vary drastically
pb <- txtProgressBar(min = 1, max = length(ind), style = 3)
k <- 0
for (i in ind) {
  k <- k + 1
  setTxtProgressBar(pb, k)
  
  # load settings
  inp_sel <- sim_settings[i, ]
  
  # start actual simulation
  nMC <- inp_sel$nMC
  
  set.seed(inp_sel$seed)
  
  # generate covariate data
  n_i <- inp_sel$n
  d_i <- inp_sel$d
  sigma2_i <- inp_sel$sigma2
  
  X <- matrix(runif(n_i*d_i), nrow = n_i, ncol = d_i)
  XMC <- matrix(runif(nMC*d_i), nrow = nMC, ncol = d_i)
  
  unit_errors <- rnorm(n_i)
  
  m_j <- inp_sel$m
  
  # recover eta() from eta_name
  eta_j <- eval(parse(text = paste0("function(x) {", inp_sel$eta_name, "}")))
  
  # normalize regression function on unit cube
  eta_norm <- function(x) (eta_j(x) - eta_j(rep(0,d_i)))/
      (eta_j(rep(1,d_i)) - eta_j(rep(0,d_i)))
  
  tau_j <- inp_sel$tau_num
  
  # calculate response
  eta_X <- apply(X, MARGIN = 1, FUN = eta_norm)
  y <- eta_X + sqrt(sigma2_i) * unit_errors
  
  # Actually run the subgroup selection procedure
  FWER_control_j <- inp_sel$procedure
  
  if (FWER_control_j == "split oracle") { # provide eta if "split oracle":
    time_in <- Sys.time()
    X_rej <- ISS(X = X, y = y, tau = tau_j, alpha = alpha,
                 m = m_j, p_value = p_value_method, sigma2 = sigma2_i,
                 rho = rho, FWER_control = FWER_control_j,
                 split_proportion = 1/2, eta = eta_j)
    time_diff <- Sys.time() - time_in
  } else { # don't provide eta otherwise (would not be used anyway)
    time_in <- Sys.time()
    X_rej <- ISS(X = X, y = y, tau = tau_j, alpha = alpha,
                 m = m_j, p_value = p_value_method, sigma2 = sigma2_i,
                 rho = rho, FWER_control = FWER_control_j,
                 split_proportion = 1/2, eta = NA)
    time_diff <- Sys.time() - time_in
  }
    
  

  # evaluate result
  # data point evaluation
  inp_sel$number_of_rejected_testpoints <- nrow(X_rej)
  X_rej_eta <- apply(X_rej, MARGIN = 1, FUN = eta_norm)
  inp_sel$number_of_rejected_testpoints_in_superlevelset <- sum(X_rej_eta >= tau_j)
  inp_sel$is_in_superlevelset <- inp_sel$number_of_rejected_testpoints == inp_sel$number_of_rejected_testpoints_in_superlevelset

  # Monte Carlo evaluation
  MCpoints_superlevelset_evaluation <- superlevelset_evaluation(X = XMC, X_rej = X_rej, t = tau_j, f = eta_norm)
  inp_sel$number_of_MCpoints_in_superlevelset <- MCpoints_superlevelset_evaluation[[1]]
  inp_sel$number_of_rejected_MCpoints_in_superlevelset <- MCpoints_superlevelset_evaluation[[2]]
  inp_sel$MC_rejection_proportion <- inp_sel$number_of_rejected_MCpoints_in_superlevelset/inp_sel$number_of_MCpoints_in_superlevelset
  inp_sel$MC_missed_proportion <- 1 - inp_sel$MC_rejection_proportion
  
  #inp_sel$rejected_lebesgue_vol_unitcube <- NA #area_of_rejected_set, not functional, placeholder
  
  inp_sel$time <- as.numeric(time_diff, units = "secs")
  
  # save result
  sim_settings[i, ] <- inp_sel
  
}

save(sim_settings, file = "sim_settings_revision_res.RData")
