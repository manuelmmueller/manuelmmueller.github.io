# Author: Manuel Mueller, mm2559@cam.ac.uk
# Description: Reproduce the simulation plots in https://arxiv.org/abs/2305.04852

#rm(list = ls())

# ============= 0. Setup =======================================================
library(tidyverse)
library(cowplot)
library(viridis)
library(latex2exp)
library(showtext)

# Installation of Computer Modern fonts might be required. 
# If installation is not desired it is possible to adjust the font settings in ggplot calls.
font_library <- "/Library/Fonts/"
font_add("CMU Serif", regular = paste0(font_library, "cmunrm.ttf"), italic = paste0(font_library, "cmunti.ttf"))
font_add("CMU Serif Italic", regular = paste0(font_library, "cmunti.ttf"))
showtext_auto()

# Load RData-File then run the following preparation
sim <- get(load("sim_settings.RData"))

# ============= 1. Choose plot to reproduce ====================================
function_choice <- "main" # CHOOSE. options: "main", "appendix"
chosen_d <- 2 # CHOOSE. options: 2, 3, 4
alternatives_choice <- "competitive" # CHOOSE. options: "competitive", "sample_splitting"

# ================ FROM HERE ONWARDS: AVOID MAKING CHANGES =====================
# ============= 2. Prepare plots  ==============================================
# number of simulation runs and Monte Carlo simulations
grouping_variables <- c("n", "d", "sigma2", "procedure", "eta_name")
grouped_counts <- aggregate(sim$n, by = sim[grouping_variables], FUN = length)
range(grouped_counts$x)
if (min(grouped_counts$x) == max(grouped_counts$x)){ #should be true
  M <- grouped_counts$x[1]
}

if (length(unique(sim$nMC)) == 1){ #should be true
  nMC_overall <- sim$nMC[1]
}

# considered regression functions
eta_list <- list(
  function(x) sum(x),
  function(x) max(x),
  function(x) min(x),
  function(x) as.integer(x[1] > 0.5),
  function(x) sum((x - 0.5)^3),
  function(x) x[1],
  function(x) exp(sum(x)),
  function(x) 1/(1 + exp(-sum((x-0.5)*4))),
  function(x) sum(x^3),
  function(x) sum((x - 1)^3),
  function(x) sum(ceiling(x*6)/6),
  function(x) if(length(x) == 1) {sqrt(x[1])} else {sqrt(x[1]) + x[2]},
  function(x) sign(sum((x - 0.5))) * abs(sum((x - 0.5)))^(1/3),
  function(x) sum((x - 0.5))^3
)

(eta_name_overview <- sapply(eta_list, FUN = function(x) paste0(deparse(x)[-1], collapse = "")))

# consequences of user choices above
chosen_sigma2 <- c("2" = 1/4^2, "3" = 1/16^2, "4" = 1/64^2)[as.character(chosen_d)]

function_inclusion <- list("main" = 1:6, "appendix" = 7:14)[[function_choice]]
included_function_letters <- letters[function_inclusion]
included_function_names <- eta_name_overview[function_inclusion]
data.frame(included_function_letters, included_function_names)
eta_list_subset <- eta_list[function_inclusion]

included_procedures <- list("competitive" = c("ISS", "Holm", "MG all", "MG any"),
                            "sample_splitting" = c("ISS",
                                                   "split",
                                                   "split oracle"))[[alternatives_choice]]
latex_procedure_labels <- list("competitive" = unname(TeX(c("$\\hat{\\textit{A}}^{ISS}$",
                                                            "$\\hat{\\textit{A}}^{ISS, H}$",
                                                            "$\\hat{\\textit{A}}^{ISS, All}$",
                                                            "$\\hat{\\textit{A}}^{ISS, Any}$"))),
                               "sample_splitting" = unname(TeX(c("$\\hat{\\textit{A}}^{ISS}$",
                                                                 "$\\hat{\\textit{A}}^{Split}$",
                                                                 "$\\hat{\\textit{A}}^{Split,OR}$"))))[[alternatives_choice]]

# resulting plotting parameters
number_rows <- 2
number_cols <- c("main" = 3, "appendix" = 4)[function_choice]
differing_yscale_width <- c("3" = 10.5, "4" = 13.5)[as.character(number_cols)]
fixed_yscale_width <- c("3" = 9, "4" = 11.5)[as.character(number_cols)]
contour_plots_width <- c("3" = 8.5, "4" = 11.35)[as.character(number_cols)]
height <- 6


# ============= 3. Contour line plots  =========================================
m <- 100
xx <- (1:m)/m
xxyy <- as.matrix(expand.grid(xx, xx))
plotlist <- vector(mode = "list", length = length(eta_list_subset))

for (i_eta in 1:length(eta_list_subset)) {
  eta <- eta_list_subset[[i_eta]]
  eta_xxyy <- apply(xxyy, MARGIN = 1, FUN = eta)

  plot_xxyy_eta <- cbind(xxyy, eta_xxyy)
  plot_xxyy_eta_df <- as.data.frame(plot_xxyy_eta)
  names(plot_xxyy_eta_df) <- c("x", "y", "eta")

  plot_xxyy_eta_df$eta[plot_xxyy_eta_df$eta == 1] <- 0.9999 # workaround to avoid another contour line

  plotlist[[i_eta]] <-
    ggplot(plot_xxyy_eta_df, aes(x, y, fill = eta))+
    geom_tile() +
    scale_fill_viridis(discrete=FALSE) +
    theme_bw() +
    theme(legend.position = "none", axis.title = element_blank(),
          text=element_text(size=12, family="CMU Serif"),
          panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    ggtitle(label = paste0("(", included_function_letters[i_eta], ")")) +
    scale_alpha_identity() +
    geom_contour(data = plot_xxyy_eta_df, aes(x = x, y = y, z = eta), bins = 6, col = "red")
}


grid_plot <- plot_grid(plotlist = plotlist, align = "hv", nrow = number_rows, ncol = number_cols)
grid_plot
#ggsave(filename = paste0("sim_reg_functions_2D.pdf"), plot = grid_plot, height = height, width = contour_plots_width)



# ============= 4. Simulation results  =========================================

sim_plot <- sim %>% filter(d == chosen_d,
                           sigma2 == chosen_sigma2,
                           eta_name %in% included_function_names,
                           procedure %in% included_procedures) %>%
    group_by(n, procedure, m, eta_name) %>%
    summarise(mean_missed_proportion = mean(MC_missed_proportion, na.rm = T),
              empvar_missed_proportion = var(MC_missed_proportion, na.rm = T),
              no_MCpoints_in_superlevelset = sum(number_of_MCpoints_in_superlevelset == 0),
              mean_computation_time = mean(time, na.rm = T),
              se_computation_time = sd(time, na.rm = T)/sqrt(sum(!is.na(time))),
              type_1_error = mean(!is_in_superlevelset),
              number_of_instances = length(n)) #just count how many in that group


sim_plot$procedure <- factor(sim_plot$procedure,
                               levels = included_procedures,
                               labels = latex_procedure_labels)

nbreaks <- sort(unique(sim$n))
sim_plot$eta_name <- factor(sim_plot$eta_name, levels = included_function_names)
labeller_f <- c(paste0("(", included_function_letters, ")"))
names(labeller_f) <- included_function_names


# ============= 4.1 Performance  ===============================================

performance_plot <- sim_plot %>% filter(eta_name %in% (eta_name_overview[function_inclusion])) %>% ggplot(aes(x = n, y = mean_missed_proportion,
                       color = procedure, shape = procedure)) +
    geom_point(alpha = 0.75) +
    geom_line(alpha = 0.75) +
    facet_wrap( ~ eta_name, nrow = number_rows, labeller = as_labeller(labeller_f), scales = "free_y") +
    theme_bw() +
    ylab("Average regret") +
    labs(color = "Method", shape = "Method") +
    scale_color_discrete(labels = latex_procedure_labels) +
    scale_shape_discrete(labels = latex_procedure_labels) +
    scale_x_continuous(breaks = nbreaks, minor_breaks = NULL) +
    theme(text=element_text(size=16, family="CMU Serif")) +
    theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1),
          axis.title.x = element_text(family = "CMU Serif Italic")) +
    theme(legend.text.align = 0,
          legend.title.align = 0.5,
          legend.text = element_text(size = 14)) +
    geom_errorbar(aes(ymin = pmax(0, mean_missed_proportion - qnorm(0.975)/sqrt(M) *
                                    sqrt(mean_missed_proportion * (1 - mean_missed_proportion)/(nMC_overall) + empvar_missed_proportion)),
                      ymax = pmin(1, mean_missed_proportion + qnorm(0.975)/sqrt(M) *
                                    sqrt(mean_missed_proportion * (1 - mean_missed_proportion)/(nMC_overall) + empvar_missed_proportion))),
                  linewidth = 0.5)
performance_plot
#ggsave(filename = paste0("performance.pdf"), plot = performance_plot, height = height, width = differing_yscale_width)


# ============= 4.2 Computation time  ==========================================

yrange <- range(sim_plot$mean_computation_time)
power_range <- c(floor(log10(yrange[1])), ceiling(log10(yrange[2])))

runtime_plot <- sim_plot %>% filter(eta_name %in% (eta_name_overview[function_inclusion])) %>%
    ggplot(aes(x = n, y = mean_computation_time, color = procedure, shape = procedure)) +
    geom_point(alpha = 0.75) +
    geom_line(alpha = 0.75) +
    facet_wrap( ~ eta_name, nrow = number_rows, labeller = as_labeller(labeller_f)) +
    theme_bw() +
    ylab("Time") +
    labs(color = "Method", shape = "Method") +
    scale_color_discrete(labels = latex_procedure_labels) +
    scale_shape_discrete(labels = latex_procedure_labels) +
    scale_x_continuous(breaks = nbreaks, minor_breaks = NULL) +
    scale_y_log10(minor_breaks = NULL, limits = 10^power_range,
     breaks=c(0.01, 0.1, 1, 10, 60, 600, 3600),
     labels=c("0.01s", "0.1s", "1s", "10s", "1m", "10m", "1h")) +
    theme(text=element_text(size=16, family="CMU Serif")) +
    theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1),
      axis.title.x = element_text(family = "CMU Serif Italic")) +
    theme(legend.text.align = 0,
          legend.title.align = 0.5,
          legend.text = element_text(size = 14))

runtime_plot
#ggsave(filename = paste0("runtime.pdf"), plot = runtime_plot, height = height, width = fixed_yscale_width)





