# Author: Manuel Mueller, mm2559@cam.ac.uk
# Description: Reproduce the real-data applications in https://arxiv.org/abs/2305.04852

#rm(list = ls())

# ============= 0. Setup =======================================================
library(ISS)  # requires version 1.0.0 or higher

library(speff2trial) #ACTG175 data
library(tidyverse)
library(latex2exp)
library(showtext)
# Installation of Computer Modern fonts might be required. 
# If installation is not desired it is possible to adjust the font settings in ggplot calls.
font_add("CMU Serif", regular = "/Library/Fonts/cmunrm.ttf", italic = "/Library/Fonts/cmunti.ttf")
font_add("CMU Serif Italic", regular = "/Library/Fonts/cmunti.ttf")
showtext_auto()

# ============= 1. ACTG - univariate risk group estimation =====================

## data preparation
d <- as_tibble(ACTG175)
d <- d %>% filter(arms == 0)
var_name <- "age"
X_orig <- as.matrix(d[var_name])
invert_col <- TRUE # high age makes good outcome less likely
X <- X_orig
X[, invert_col] <- -X[, invert_col]
y <- as.numeric(d$cens == 0)

## estimate
tau <- 0.5
(X_rej <- ISS(X = X, y = y, tau = tau, alpha = 0.05, sigma2 = 1/4, minimal = TRUE))

X_rej_orig <- X_rej
X_rej_orig[, invert_col] <- -X_rej_orig[, invert_col]

X_rej_orig

## plot
plot_df <- as.data.frame(cbind(y, X_orig))

isofit <- isoreg(y ~ X)

set.seed(100)
univ_plot <- ggplot(plot_df, aes(x = age, y = jitter(y, 0.2))) +
    geom_point(alpha = 0.3) +
    geom_step(data = data.frame(iso_y = isofit$yf, iso_x = X[isofit$ord]), aes(x = -iso_x, y = iso_y), linewidth = 1) +
    theme_bw() +
    scale_x_reverse(breaks = 10 * 1:7) +
    geom_vline(xintercept = X_rej_orig, color = "lightcoral") +
    geom_hline(yintercept = tau, color = "blue", linetype = "dashed") +
    theme(text=element_text(size=18, family="CMU Serif")) +
    xlab("Age (years)") +
    ylab("Patient health")

univ_plot

#ggsave(filename = "actg175_univariate.pdf", plot = univ_plot, height = 7.5, width = 10.5)




# ============= 2. ACTG - bivariate risk group estimation ======================
## data preparation
d <- as_tibble(ACTG175)
d <- d %>% filter(arms == 0)
var_names <- c("age", "cd40")
X_orig <- as.matrix(d[var_names])
y <- as.numeric(d$cens == 0)
invert_col <- c(TRUE, FALSE) # high age makes good outcome less likely
X <- X_orig
X[, invert_col] <- -X[, invert_col]

X_scaled <- scale(X)

## estimate
tau <- 0.5
(X_rej <- ISS(X = X_scaled, y = y, tau = tau, alpha = 0.05, sigma2 = 1/4, minimal = TRUE))

X_rej_orig <- X_rej
X_rej_orig <- t(t(X_rej_orig) * attr(X_scaled, "scaled:scale") + attr(X_scaled, "scaled:center"))

X_rej_orig[, invert_col] <- -X_rej_orig[, invert_col]

X_rej_orig

## plot
plot_df <- as.data.frame(cbind(y, X_orig))

biv_plot <- ggplot(plot_df, aes(x = age, y = cd40)) +
  geom_point(alpha = 0) +
  theme_bw() +
  scale_x_reverse(breaks = 7:1 * 10) +
  scale_y_continuous(breaks = 100 * 1:8)

plot_range_x <- -ggplot_build(biv_plot)$layout$panel_params[[1]]$x.range #negative since reversed
plot_range_y <- ggplot_build(biv_plot)$layout$panel_params[[1]]$y.range

for (i in 1:nrow(X_rej_orig)) {
  rect_i <- data.frame(xmin = X_rej_orig[i,1], ymin = X_rej_orig[i, 2], 
                       xmax = plot_range_x[2], ymax = plot_range_y[2])
  biv_plot <- biv_plot + geom_rect(data = rect_i, inherit.aes = FALSE,
                                   mapping = aes(xmin = xmin, ymin = ymin, 
                                                 xmax = xmax, ymax = ymax),
                                   fill = "lightcoral")
}


biv_plot <- biv_plot + geom_point(alpha = 0.5) +
  theme(text=element_text(size=18, family="CMU Serif")) +
  ylab(expression(paste("CD4 cell count per ", mm^3, " at baseline"))) +
  theme(text=element_text(size=18, family="CMU Serif")) +
  xlab("Age (years)")
biv_plot

#ggsave(filename = "actg175_bivariate.pdf", plot = biv_plot, height = 7.5, width = 10.5)





# ============= 3. ACTG - heterogenous treatment effect ========================
## data preparation
d <- as_tibble(ACTG175)
d <- d %>% filter(arms %in% c(0, 2))
d <- d %>% mutate(response = (4*(arms != 0) - 2) * (cd420 - cd40))

var_name <- "age"
X_orig <- as.matrix(d[var_name])
invert_col <- TRUE  # high age makes good outcome less likely
X <- X_orig
X[, invert_col] <- -X[, invert_col]
y <- as.numeric(d$response >= 0)

## estimate
tau <- 0.5
(X_rej <- ISS(X = X, y = y, tau = tau, alpha = 0.05, p_value = "classification", 
              minimal = TRUE))

X_rej_orig <- X_rej
X_rej_orig[, invert_col] <- -X_rej_orig[, invert_col]

X_rej_orig

## plot
plot_df <- as.data.frame(cbind(y, X_orig))

isofit <- isoreg(y ~ X)

set.seed(100)
hte_plot <- ggplot(plot_df, aes(x = age, y = jitter(y, 0.2))) +
    geom_point(alpha = 0.3) +
    geom_step(data = data.frame(iso_y = isofit$yf, iso_x = X[isofit$ord]), aes(x = -iso_x, y = iso_y), linewidth = 1) +
    theme_bw() +
    scale_x_reverse(breaks = 10 * 1:8) +
    geom_vline(xintercept = X_rej_orig, color = "lightcoral", linewidth = 1) +
    geom_hline(yintercept = tau, color = "blue", linetype = "dashed", linewidth = 1) +
    theme(text=element_text(size=18, family="CMU Serif")) +
    xlab("Age (years)") +
    ylab("Alternative treatment non-inferior (1 = yes, 0 = no)")
hte_plot


#ggsave(filename = "actg175_hte.pdf", plot = hte_plot, height = 7.5, width = 10.5)



# ============= 4. Auto MPG - superlevel set estimation ========================
## data preparation
# reference link: https://archive.ics.uci.edu/dataset/9/auto+mpg
# direct download link: https://archive.ics.uci.edu/static/public/9/auto+mpg.zip
names_file <- read_table("auto-mpg.names", skip = 30, n_max = 9)
(autompg_vardescription <- unlist(names_file[,2]))
autompg_vardescription <- gsub(pattern =":", replacement = "", autompg_vardescription)
names(autompg_vardescription) <- NULL
autompg_vardescription[autompg_vardescription == "model"] <- "year" # appropriate name

d <- read_table("auto-mpg.data", 
                col_names = autompg_vardescription[-length(autompg_vardescription)], 
                comment = '"', na = "?") # don't need model name

var_names <- c("weight", "displacement")
X_orig <- as.matrix(d[var_names])
y <- as.numeric(d$mpg >= 15)
invert_col <- c(TRUE, TRUE)
X <- X_orig
X[, invert_col] <- -X[, invert_col]

X_scaled <- scale(X)

## estimate
tau <- 0.5
(X_rej <- ISS(X = X_scaled, y = y, tau = tau, alpha = 0.05, sigma2 = 1/4, minimal = T))

X_rej_orig <- X_rej
X_rej_orig <- t(t(X_rej_orig) * attr(X_scaled, "scaled:scale") + attr(X_scaled, "scaled:center"))
X_rej_orig[, invert_col] <- -X_rej_orig[, invert_col]
X_rej_orig <- X_rej_orig[order(X_rej_orig[, var_names[1]]), ]
X_rej_orig


## plot
plot_df <- as.data.frame(cbind(y, X_orig))

autompg_plot <- ggplot(plot_df, aes(x = weight, y = displacement)) +
  geom_point(alpha = 0) +
  theme_bw() +
  scale_x_reverse() +
  scale_y_reverse()

plot_range_x <- -ggplot_build(autompg_plot)$layout$panel_params[[1]]$x.range 
plot_range_y <- -ggplot_build(autompg_plot)$layout$panel_params[[1]]$y.range

for (i in 1:nrow(X_rej_orig)) {
  rect_i <- data.frame(xmin = X_rej_orig[i,1], ymin = X_rej_orig[i, 2], 
                       xmax = plot_range_x[2], ymax = plot_range_y[2])
  autompg_plot <- autompg_plot + geom_rect(data = rect_i, inherit.aes = F,
                                   mapping = aes(xmin = xmin, ymin = ymin, 
                                                 xmax = xmax, ymax = ymax),
                                   fill = "lightcoral")
}


autompg_plot <- autompg_plot + geom_point(alpha = 0.5) +
  theme(text=element_text(size=18, family="CMU Serif")) +
  ylab("Engine displacement (cu in)") +
  xlab("Weight (lbs)")
autompg_plot


#ggsave(filename = "auto-mpg.pdf", plot = autompg_plot, height = 7.5, width = 10.5)
